CREATE DATABASE Project_02;
USE Project_02;
/*
load data of Census1 and 
load data of Census2
*/

-- show our dataset 
SELECT * FROM Census1;
SELECT * FROM Census2;

-- number of rows into our dataset
SELECT COUNT(*) FROM Census1;
SELECT COUNT(*) FROM Census2;

-- dataset for jharkhand and bihar
SELECT * FROM Census1
WHERE state IN('Jharkhand', 'Bihar');

-- number of population of india
SELECT SUM(population) AS "Population" FROM Census2;

-- avg growth of india
SELECT state, AVG(growth*100) AS "avg_population_growth_%" FROM Census1
GROUP BY State;

-- avg sex ratio
SELECT state, ROUND(AVG(sex_ratio),0) AS "avg_sex_ratio_growth" FROM Census1
GROUP BY state
ORDER BY avg_sex_ratio_growth DESC;

-- avg literacy rate
SELECT state, ROUND(AVG(literacy),0) AS "avg_literacy_rate" FROM Census1
GROUP BY state
HAVING AVG(literacy) > 90 
ORDER BY avg_literacy_rate DESC;

-- top 3 states showing highest growth ratio
SELECT state, ROUND(AVG(growth)*100,0) AS "avg_growth" FROM Census1
GROUP BY state
ORDER BY avg_growth DESC LIMIT 3;

-- bottom 3 states showing highest growth ratio
SELECT state, ROUND(AVG(growth)*100,0) AS "avg_growth" FROM Census1
GROUP BY state
ORDER BY avg_growth LIMIT 3;

-- top 3 states showing highest sex ratio
SELECT state, sum(sex_ratio) AS "avg_sex_rartio" FROM Census1
GROUP BY state
ORDER BY avg_sex_rartio LIMIT 3;

-- top 3 and bottom 3 sstate in literacy rate
DROP TABLE IF EXISTS top3;
CREATE TABLE top3
(
state VARCHAR(30),
topstates FLOAT
);
INSERT INTO top3 SELECT state, ROUND(AVG(literacy),0) AS "avg_literacy_rate" FROM Census1
GROUP BY state 
ORDER BY avg_literacy_rate DESC LIMIT 3;
SELECT * FROM top3;

DROP TABLE IF EXISTS bottom3;
CREATE TABLE bottom3
(
state VARCHAR(30),
bottomstates FLOAT
);
INSERT INTO bottom3 SELECT state, ROUND(AVG(literacy),0) AS "avg_literacy_rate" FROM Census1
GROUP BY state 
ORDER BY avg_literacy_rate LIMIT 3;
SELECT * FROM bottom3;

-- union operator 
(SELECT * FROM top3 
ORDER BY topstates DESC) 
UNION
(SELECT * FROM bottom3 
ORDER BY bottomstates);

-- states starting with letter 'A'
SELECT * FROM Census1
WHERE state LIKE 'a%';

-- states starting with letter 'A or B'
SELECT DISTINCT state FROM Census1
WHERE state LIKE 'a%' OR state LIKE 'b%';

-- states starting with letter 'A' and ending with letter 'M'
SELECT * FROM Census1
WHERE state LIKE 'a%m';

-- joining both table
SELECT a.district, a.state, a.sex_ratio/1000, b.population FROM Census1 AS a 
INNER JOIN Census2 AS b
ON a.district=b.district;

/*
female/males = sex_ratio...........1
females+males = population.........2
females = population-males.........3
(population-males) = sex_ration*males
population = males(sex_ratio+1)
males = population/(sex_ratio+1)---------------MALES
femails = population-population/(sex_ratio+1)
        = population(1-1/(sex_ration))
		= (population*(sex_ratio))/(sex_ratio+1)
*/

-- total number of males and females
CREATE TABLE IF NOT EXISTS Number_of_male_female
(SELECT c.district, c.state, ROUND(c.population/((c.sex_ratio)+1),0) AS "Males", ROUND((c.population*(c.sex_ratio))/(c.sex_ratio+1),0) AS "Females", c.sex_ratio
FROM (SELECT a.district, a.state, a.sex_ratio/1000 AS "sex_ratio", b.population FROM Census1 AS a 
INNER JOIN Census2 AS b
ON a.district=b.district) AS c);

-- total number of males and females in each state
SELECT d.state, SUM(d.males) AS "total males", SUM(d.females) AS "total females" FROM
(SELECT c.district, c.state, ROUND(c.population/((c.sex_ratio)+1),0) AS "Males", ROUND((c.population*(c.sex_ratio))/(c.sex_ratio+1),0) AS "Females", c.sex_ratio
FROM (SELECT a.district, a.state, a.sex_ratio/1000 AS "sex_ratio", b.population FROM Census1 AS a 
INNER JOIN Census2 AS b
ON a.district=b.district) AS c) AS d
GROUP BY d.state;

-- total literacy rate
/*

SELECT a.district, a.state, a.literacy AS "literacy", b.population FROM Census1 AS a 
INNER JOIN Census2 AS b
ON a.district=b.district;
-- total literacy rate
*/

CREATE TABLE IF NOT EXISTS Number_of_literate_people
(SELECT c.state, sum(literate_people) total_literate_pop, sum(illiterate_people) total_lliterate_pop FROM 
(SELECT d.district,d.state, round(d.literacy_ratio*d.population,0) literate_people,
round((1-d.literacy_ratio)* d.population,0) illiterate_people FROM
(SELECT a.district, a.state, a.literacy/100 literacy_ratio, b.population FROM Census1 a 
inner join Census2 b on a.district=b.district) d) c
GROUP BY c.state);

-- population in previous census


select sum(m.previous_census_population) previous_census_population,sum(m.current_census_population) current_census_population from(
select e.state,sum(e.previous_census_population) previous_census_population,sum(e.current_census_population) current_census_population from
(select d.district,d.state,round(d.population/(1+d.growth),0) previous_census_population,d.population current_census_population from
(select a.district,a.state,a.growth growth,b.population from Census1 a inner join Census2 b on a.district=b.district) d) e
group by e.state)m;


-- population vs area

select (g.total_area/g.previous_census_population)  as previous_census_population_vs_area, (g.total_area/g.current_census_population) as 
current_census_population_vs_area from
(select q.*,r.total_area from (

select '1' as keyy,n.* from
(select sum(m.previous_census_population) previous_census_population,sum(m.current_census_population) current_census_population from(
select e.state,sum(e.previous_census_population) previous_census_population,sum(e.current_census_population) current_census_population from
(select d.district,d.state,round(d.population/(1+d.growth),0) previous_census_population,d.population current_census_population from
(select a.district,a.state,a.growth growth,b.population from Census1 a inner join Census2 b on a.district=b.district) d) e
group by e.state)m) n) q inner join (

select '1' as keyy,z.* from (
select sum(area_km2) total_area from Census2)z) r on q.keyy=r.keyy)g;

-- window 

-- output top 3 districts from each state with highest literacy rate


select a.* from
(select district,state,literacy,rank() over(partition by state order by literacy desc) rnk from Census1) a

where a.rnk in (1,2,3) order by state;

