CREATE DATABASE Portfolio_Project_1;
USE Portfolio_Project_1;

-- Inspecting Data
SELECT * FROM sales_data;
select ORDERDATE date from sales_data;


-- Checking Unique Values
SELECT DISTINCT status from sales_data;  -- Nice to plot
SELECT DISTINCT year_id from sales_data;
SELECT DISTINCT PRODUCTLINE from sales_data;  -- Nice to plot
SELECT DISTINCT COUNTRY from sales_data;  -- Nice to plot
SELECT DISTINCT DEALSIZE from sales_data;  -- Nice to plot
SELECT DISTINCT TERRITORY from sales_data;  -- Nice plot


-- Analysis
-- let's start by grouping sales by productline
SELECT PRODUCTLINE, SUM(sales) Revenue 
from sales_data
group by PRODUCTLINE
order by 2 desc;

SELECT year_id, SUM(sales) Revenue 
from sales_data
group by year_id
order by 2 desc;

SELECT DISTINCT month_id 
from sales_data
where year_id =2005
order by month_id;

SELECT dealsize, SUM(sales) Revenue 
from sales_data
group by dealsize
order by 2 desc;


-- best month for sale
SELECT month_id, sum(sales) Revnue, count(ordernumber) Frequency
FROM sales_data
where year_id=2004  -- change year to see rest
group by month_id
order by 2 desc;


-- november seems to best month, what product do they sell in november
SELECT month_id, productline, sum(sales) Revnue, count(ordernumber) Frequency
FROM sales_data
where year_id=2004 and month_id=11  -- change year to see rest
group by month_id, productline
order by 3 desc;


-- who is our best customer (this could be best answered with RFM)
drop table temp_rfm;
create TABLE if not exists temp_rfm
with rfm as
(
select
	customername,
	sum(sales) monetaryvalue,
	avg(sales) Avgmonetaryvalue,
	count(ordernumber) Frequency,
	max(orderdate) last_order_date,
	(select max(orderdate) from sales_data) max_order_date,
	DATEDIFF((select max(orderdate) from sales_data), max(orderdate)) Recency
	from sales_data
	group by customername
),
rfm_calc as
(
	select r.*, 
	ntile(4) over (order by recency desc) rfm_recency,
	ntile(4) over (order by Frequency) rfm_Frequency,
	ntile(4) over (order by Avgmonetaryvalue) rfm_monetary
	from rfm r
)
	select c.*,rfm_recency+rfm_Frequency+rfm_monetary as rfm_cell,
	concat(CAST(rfm_recency as char),CAST(rfm_Frequency as char),CAST(rfm_monetary as char)) rfm_cell_string
	from rfm_calc c;

select * from temp_rfm;

select customername, rfm_recency, rfm_Frequency, rfm_monetary,
case 
	when rfm_recency in (1,2,3) and rfm_Frequency in (1,2,3,4) and rfm_cell in (5,6,7,8) then "new customers"
    when rfm_recency in (1,2,3) and rfm_Frequency in (2,3) and rfm_monetary in (2,3,4) then "potential customer"
    when rfm_recency in (2,3,4) and rfm_Frequency in (1,2) and rfm_cell in (7,8,9) then "slipping away, cannot lose"
	when rfm_recency in (1,2,3) and rfm_Frequency in (1,2) and rfm_cell in (3,4,5,6,7) then "lost customer"
	when rfm_cell in (8,9,10,11,12,13) and rfm_Frequency in (2,3,4,5) and rfm_recency in (1,2,3,4) and rfm_monetary in (1,2,3,4)then "loyal customers"
end temp_temp_segment
from temp_rfm;


-- what product are most often sold together
-- select * from sales_data where ordernumber=10411;
select distinct productcode 
from sales_data
where ordernumber in 
(
select ordernumber
from(
select distinct ordernumber, count(*) rn
from sales_data
where status = 'shipped'
group by ordernumber
) m
where rn=2
);

